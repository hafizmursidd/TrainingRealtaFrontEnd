﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AuthCommon
{
    public class TokenDTO
    {
        public string token { get; set; }
    }
}
