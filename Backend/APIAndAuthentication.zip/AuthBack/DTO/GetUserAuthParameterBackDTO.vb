﻿Public Class GetUserAuthByIdParameterBackDTO
    Public Property CCOMPANY_ID As String
    Public Property CUSER_ID As String
End Class
