﻿Public Class UpdateRefreshTokenParameterBackDTO
    Public Property CCOMPANY_ID As String
    Public Property CUSER_ID As String
    Public Property CREFRESH_TOKEN As String
    Public Property DREFRESH_TOKEN_UTC_CREATED As Date
    Public Property DREFRESH_TOKEN_UTC_EXPIRES As Date
    Public Property CTOKEN_IP_ADDRESS As String
End Class
