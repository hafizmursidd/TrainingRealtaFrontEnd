﻿Public Class GetUserAuthByRefreshTokenParameterBackDTO
    Public Property CREFRESH_TOKEN As String
End Class
