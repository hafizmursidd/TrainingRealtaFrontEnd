﻿Imports R_BackEnd

Public Class GSH00100DTOnon
    Inherits R_DTOBase

    Public Property CRECID As String
    Public Property CCOMPANY_ID As String
    Public Property CTABLE_ID As String
    Public Property CTABLE_NAME As String
    Public Property CPROGRAM_ID As String
    Public Property CUSER_ID As String
    Public Property CUSER_NAME As String
    Public Property CACTION_FLAG As String
    Public Property CINFO_VALUE As String
    Public Property DAUDIT_DATE As DateTime
    Public Property CFIELD_ID As String
    Public Property CFIELD_NAME As String
    Public Property COLD_VALUE As String
    Public Property CNEW_VALUE As String
End Class
