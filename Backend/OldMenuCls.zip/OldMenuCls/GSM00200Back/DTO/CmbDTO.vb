﻿Imports R_BackEnd

Public Class CmbDTO
    Inherits R_DTOBase

    Public Property CCODE As String
    Public Property CVALUE As String
End Class
