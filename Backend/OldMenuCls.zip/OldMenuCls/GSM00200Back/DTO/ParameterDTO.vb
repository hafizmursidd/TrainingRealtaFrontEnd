﻿Imports R_BackEnd

Public Class ParameterDTO
    Inherits R_DTOBase

    Public Property CCOMPANY_ID As String
    Public Property CGROUP_LIST As String
    Public Property CFIELD_LIST As String
    Public Property CDATE_FROM As String
    Public Property CDATE_TO As String
    Public Property CUSER_LIST As String
    Public Property CACTION_LIST As String
    Public Property CPROGRAM_LIST As String
End Class
