﻿using System;

namespace SAB00100FrontResources
{
    public class Resources_Dummy_Class
    {
    }
}